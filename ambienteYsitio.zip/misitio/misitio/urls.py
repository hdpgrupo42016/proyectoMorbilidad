"""misitio URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import patterns, include, url
from django.contrib import admin
from morbilidadapp.views import misEnfermedades
from morbilidadapp.views import cc1
from morbilidadapp.views import cc2
from morbilidadapp.views import cc0

urlpatterns = [
	url(r'^admin/', admin.site.urls),
	url(r'^primeravista/$','morbilidadapp.views.mi_primer_vista'),
	url(r'^enfermedades/$',misEnfermedades),
	url(r'^cc1/$',cc1),
	url(r'^cc2/$',cc2),
	url(r'^cc0/$',cc0),
]
