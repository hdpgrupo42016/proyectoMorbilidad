from django.contrib import admin
from morbilidadapp.models import enfermedad, tipoEnfermedad, morbilidad, detalleMorbilidad

# Register your models here.

class enfermedadAdmin(admin.ModelAdmin):
	list_display =('idEnfermedad','idTipoEnfermedad','nombreEnfermedad','descripcionEnf')
class tipoEnfermedadAdmin(admin.ModelAdmin):
	list_display =('idTipoEnfermedad','nombreTipoEnf','descripcionTipoEnf')
class morbilidadAdmin(admin.ModelAdmin):
	list_display=('idMorbilidad','morbHombres','morbMujeres')
class detalleMorbAdmin(admin.ModelAdmin):
	list_display=('mes', 'anio','totalMorbilidad','idEnfermedad','idMorbilidad')

admin.site.register(enfermedad, enfermedadAdmin)
admin.site.register(tipoEnfermedad, tipoEnfermedadAdmin)
admin.site.register(morbilidad, morbilidadAdmin)
admin.site.register(detalleMorbilidad, detalleMorbAdmin)
