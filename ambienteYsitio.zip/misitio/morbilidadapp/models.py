from __future__ import unicode_literals

from django.db import models
from django.utils import timezone

# Create your models here.

class tipoEnfermedad(models.Model):
	idTipoEnfermedad = models.IntegerField(max_length=11,primary_key=True)
	nombreTipoEnf = models.CharField(max_length=60,null=False)
	descripcionTipoEnf = models.CharField(max_length=800,null=False)

	def __str__(self):
		return self.nombreTipoEnf 

class enfermedad(models.Model):
	idEnfermedad = models.IntegerField(max_length=11,primary_key=True)
	idTipoEnfermedad = models.ForeignKey(tipoEnfermedad, null=False)
	nombreEnfermedad = models.CharField(max_length=100,null=False)
	descripcionEnf = models.CharField(max_length=800,null=False)

	def __str__(self):
		return self.nombreEnfermedad 

class morbilidad(models.Model):
	idMorbilidad = models.IntegerField(max_length=11,primary_key=True)
	morbHombres = models.IntegerField(max_length=11,null=False)
	morbMujeres = models.IntegerField(max_length=11,null=False)

	def __str__(self):
		a=str(self.idMorbilidad)
		cadena = a
		return cadena

class detalleMorbilidad(models.Model):
	mes = models.CharField(max_length=20,null=False)
	anio = models.IntegerField(max_length=11,null=False)
	totalMorbilidad = models.IntegerField(max_length=11,null=False)
	idEnfermedad = models.ForeignKey(enfermedad, null=False)
	idMorbilidad = models.ForeignKey(morbilidad, null=False)

	def __str__(self):
		a=str(self.mes)
		b=str(self.anio)
		cadena = a+b
		return cadena 
	
