from django.shortcuts import render
from django.http import HttpResponse
from morbilidadapp.models import enfermedad
from morbilidadapp.models import detalleMorbilidad

# Create your views here.

def mi_primer_vista(request):
	return HttpResponse("Bienveido a mi primera vista")

def misEnfermedades(request):
	return render(request,"mis_Enfermedades.html",{'enfermedades':enfermedad.objects.all()}) 

def cc0(request):
	return render(request,"000.html",{'enfermedades':enfermedad.objects.all()}) 

def cc1(request):
	return render(request,"001.html",{'enfermedades':enfermedad.objects.all(),'detalleMorbilidads':detalleMorbilidad.objects.all()}) 

def cc2(request):
	return render(request,"002.html",{'cc2':enfermedad.objects.all()}) 
